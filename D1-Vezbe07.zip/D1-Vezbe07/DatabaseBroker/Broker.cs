﻿using Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseBroker
{
    public class Broker
    {
        private SqlConnection connection;
        private SqlTransaction transaction;

        public Broker()
        {
            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=D1-Prosoft;Integrated Security=True;");

        }

        public void OpenConnection()
        {
            connection.Open();
        }

        public void CloseConnection()
        {
            if (connection != null && connection.State != ConnectionState.Closed)
                connection.Close();
        }

        public void BeginTransaction()
        {
            transaction = connection.BeginTransaction();
        }

        public void Commit()
        {
            transaction.Commit();
        }

        public void Rollback()
        {
            transaction.Rollback();
        }

        public List<Manufacturer> GetAllManufacturers()
        {
            List<Manufacturer> manufacturers = new List<Manufacturer>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT * FROM Manufacturer";
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Manufacturer m = new Manufacturer();
                    m.ManufacturerId = (int)reader["Id"];
                    m.Name = (string)reader["Name"];
                    manufacturers.Add(m);
                }
            }
            return manufacturers;
        }

        //public List<Product> GetAllProducts()
        //{
        //    List<Product> products = new List<Product>();
        //    SqlCommand command = new SqlCommand("", connection);
        //    command.CommandText = "SELECT m.Id as manufacturerId, p.id as productId, m.name as manufacturerName, p.Name as productName, p.description as description, p.price as price, p.measurementunit as measurementunit FROM Product p join Manufacturer m on (p.Manufacturer=m.Id)";
        //    using (SqlDataReader reader = command.ExecuteReader())
        //    {
        //        while (reader.Read())
        //        {
        //            Product p = new Product
        //            {
        //                ProductId = (int)reader["productId"],
        //                Name = (string)reader["productName"],
        //                Description = (string)reader["description"],
        //                Price = (double)reader["price"],
        //                MeasurementUnit = (MeasurementUnit)reader["measurementunit"],
        //                Manufacturer = new Manufacturer
        //                {
        //                    ManufacturerId = (int)reader["manufacturerId"],
        //                    Name = (string)reader["manufacturerName"],
        //                }
        //            };
        //            //p.Manufacturer = new Manufacturer();
        //            //p.Manufacturer.ManufacturerId = (int)reader["manufacturerId"];
        //            //p.Manufacturer.Name = (string)reader["manufacturerName"];

        //            products.Add(p);
        //        }
        //    }
        //    return products;
        //}

        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT * FROM Product p join Manufacturer m on (p.Manufacturer=m.Id)";
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Product p = new Product
                    {
                        ProductId = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2),
                        Price = reader.GetDouble(3),
                        MeasurementUnit = (MeasurementUnit)reader.GetInt32(4),
                        Manufacturer = new Manufacturer
                        {
                            ManufacturerId = reader.GetInt32(5),
                            Name = reader.GetString(8)
                        }
                    };
                    products.Add(p);
                }
            }
            return products;
        }

        //public void AddUser(User user)
        //{
        //    SqlCommand command = new SqlCommand();
        //    command.Connection = connection;
        //    command.CommandText = "insert into [user] values (@Firstname, @Lastname, @Username, @Password)";
        //    //command.Parameters.AddWithValue("@Id", user.UserId);
        //    command.Parameters.AddWithValue("@Firstname", user.FirstName);
        //    command.Parameters.AddWithValue("@Lastname", user.LastName);
        //    command.Parameters.AddWithValue("@Username", user.Username);
        //    command.Parameters.AddWithValue("@Password", user.Password);
        //    command.ExecuteNonQuery();
        //}

        public int AddUser(User user)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "insert into [user] output inserted.id values (@Firstname, @Lastname, @Username, @Password)";
            //command.Parameters.AddWithValue("@Id", user.UserId);
            command.Parameters.AddWithValue("@Firstname", user.FirstName);
            command.Parameters.AddWithValue("@Lastname", user.LastName);
            command.Parameters.AddWithValue("@Username", user.Username);
            command.Parameters.AddWithValue("@Password", user.Password);

            int generisaniId = (int)command.ExecuteScalar();
            return generisaniId;
        }

        public int GetLastUserId()
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = $"select max(id) from [user]";
            int trenutnoNajveciId = (int)command.ExecuteScalar();
            return trenutnoNajveciId;
        }

        public void AddManufacturer(Manufacturer m)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText =
                $"insert into Manufacturer values ({m.ManufacturerId}, '{m.Name}')";

            int brojRedova = command.ExecuteNonQuery();
        }


        //public void AddProduct(Product p)
        //{
        //    SqlCommand command = new SqlCommand();
        //    command.Connection = connection;
        //    command.CommandText = $"insert into Product values ({p.ProductId}, '{p.Name}', '{p.Description}', {p.Price}, {(int)p.MeasurementUnit}, {p.Manufacturer.ManufacturerId}, '{DateTime.Now.ToString("yyyyMMdd HH:mm:ss")}')";
        //    command.ExecuteNonQuery();
        //}

        public void AddProduct(Product p)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;
            
            command.CommandText = $"insert into Product values (@Pid, @Name, @Description, @Price, @MeasurementUnit, @ManufacturerId, @Date)";

            command.Parameters.AddWithValue("@Pid", p.ProductId);
            command.Parameters.AddWithValue("@Name", p.Name);
            command.Parameters.AddWithValue("@Description", p.Description);
            command.Parameters.AddWithValue("@Price", p.Price);
            command.Parameters.AddWithValue("@MeasurementUnit", p.MeasurementUnit);
            command.Parameters.AddWithValue("@ManufacturerId", p.Manufacturer.ManufacturerId);
            command.Parameters.AddWithValue("@Date", DateTime.Now);

            command.ExecuteNonQuery();
        }

        public int GetNewProductId()
        {
            SqlCommand command = new SqlCommand("", connection, transaction);
            command.CommandText = $"select max(id) from product";

            object result = command.ExecuteScalar();

            if (result is DBNull)
            {
                return 1;
            }
            else
            {
                int trenutnoNajveciId = (int)result;
                int noviId = trenutnoNajveciId + 1;
                return noviId;
            }
        }

    }
}
