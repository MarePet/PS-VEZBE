﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class UserRepository
    {
        private List<User> users;

        public UserRepository()
        {
            users = new List<User>();
            InitUsers();
        }

        private void InitUsers()
        {
            users.Add(new User { UserId = 1, FirstName = "Pera", LastName = "Peric", Username = "pera", Password = "pera" });
            users.Add(new User { UserId = 2, FirstName = "Mika", LastName = "Mikic", Username = "mika", Password = "mika" });
            users.Add(new User { UserId = 3, FirstName = "Zika", LastName = "Zikic", Username = "zika", Password = "zika" });
        }

        public List<User> GetUsers()
        {
            return users;
        }



    }
}
