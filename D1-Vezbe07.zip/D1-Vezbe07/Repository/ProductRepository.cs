﻿using DatabaseBroker;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class ProductRepository
    {
        //private List<Product> products;

        private Broker broker = new Broker();

        public ProductRepository()
        {
            //products = new List<Product>();
        }

        public void AddProduct(Product product)
        {

        }

        public void AddAllProducts(List<Product> products)
        {
            try
            {
                broker.OpenConnection();
                broker.BeginTransaction();
                foreach(Product p in products)
                {
                    p.ProductId = broker.GetNewProductId();
                    broker.AddProduct(p);
                }
                broker.Commit();

            }
            catch(Exception ex)
            {
                broker.Rollback();
                throw;
            }
            finally
            {
                broker.CloseConnection();
            }
        }

        public List<Product> GetProducts()
        {
            try
            {
                broker.OpenConnection();
                return broker.GetAllProducts();
            }
            finally
            {
                broker.CloseConnection();
            }
        }

    }
}
