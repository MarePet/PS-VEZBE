﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class ManufacturerRepository
    {
        private List<Manufacturer> manufacturers = new List<Manufacturer>
        {
            new Manufacturer
            {
                ManufacturerId = 1,
                Name = "Manufactuter 1"
            },
            new Manufacturer
            {
                ManufacturerId = 2,
                Name = "Manufactuter 2"
            },
        };

        public List<Manufacturer> GetManufacturers()
        {
            return manufacturers;
        }

    }
}
