﻿using ApplicationLogic;
using Domain;
using Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            //User user = new User();
            //user.Username = username;
            //user.Password = password;
            //UserRepository repository = new UserRepository();
            //Controller controller = Controller.GetInstance();
            //controller.Test();
            //Controller controller = Controller.Instance;
            //controller.Test();
            //Controller.GetInstance().Test();

            if(string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                txtUsername.BackColor = Color.Salmon;
                txtPassword.BackColor = Color.Salmon;
                return;
            }


            User user = new User()
            {
                Username = username,
                Password = password,
            };

            user = Controller.Instance.Login(user);

            if(user != null)
            {
                MessageBox.Show($"Welcome, {user.FirstName} {user.LastName}!");
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("User doesnt exist!");
            }
        }
    }
}
