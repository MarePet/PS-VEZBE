﻿using ApplicationLogic;
using Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs.Dialogs
{
    public partial class AddProductDialog : Form
    {
        public AddProductDialog()
        {
            InitializeComponent();
            cbManufacturer.DataSource = Controller.Instance.GetAllManufacturers();
            cbMeasurementUnit.DataSource = Enum.GetValues(typeof(MeasurementUnit));
        }
        public Product Product { get; set; }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Product product = new Domain.Product();
                product.Name = txtName.Text;
                product.ProductId = int.Parse(txtId.Text);
                product.Description = txtDescription.Text;
                product.Price = double.Parse(txtPrice.Text);

                product.MeasurementUnit = (MeasurementUnit)cbMeasurementUnit.SelectedItem;
                product.Manufacturer = (Manufacturer)cbManufacturer.SelectedItem;

                Product = product;
                DialogResult = DialogResult.OK;

            }catch(FormatException fe)
            {
                MessageBox.Show(fe.Message);
            }


        }
    }
}
