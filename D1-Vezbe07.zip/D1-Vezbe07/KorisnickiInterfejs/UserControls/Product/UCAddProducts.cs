﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ApplicationLogic;
using Domain;

namespace KorisnickiInterfejs.UserControls.Product
{
    public partial class UCAddProducts : UserControl
    {

        private BindingList<Domain.Product> products = new BindingList<Domain.Product>();

        public UCAddProducts()
        {
            InitializeComponent();

            dgvAddProducts.DataSource = products;


            dgvAddProducts.Columns["Manufacturer"].Visible = false;
            dgvAddProducts.Columns["MeasurementUnit"].Visible = false;
            dgvAddProducts.Columns[0].Visible = false;

            DataGridViewComboBoxColumn manufacturerColumn = new DataGridViewComboBoxColumn
            {
                HeaderText = "Select manufacturer",
                DataSource = Controller.Instance.GetAllManufacturers(),
                DataPropertyName = "Manufacturer", //naziv propertija u klasi Product, gde treba da se postavi objekat iz comboboxa,
                ValueMember = "Self", //naziv propertija u klasi Manufacturer, ciju vrednost treba da vrati kada se izabere objekat iz comboboxa,
                DisplayMember = "Name" //naziv propertija u klasi Manufacturer ciju vrednost treba da prikaze u comboboxu
            };

            DataGridViewComboBoxColumn measurementUnitColumn = new DataGridViewComboBoxColumn
            {
                HeaderText = "Select measurement unit",
                DataSource = Controller.Instance.GetAllMeasurementUnits(),
                DataPropertyName = "MeasurementUnit"
            };

            dgvAddProducts.Columns.Add(manufacturerColumn);
            dgvAddProducts.Columns.Add(measurementUnitColumn);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Controller.Instance.AddAllProducts(products.ToList());
                //List<Domain.Product> list = new List<Domain.Product>();
                //BindingList<Domain.Product> bindingList = new BindingList<Domain.Product>(list);
                MessageBox.Show("Proizvodi su uspesno sacuvani!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(dgvAddProducts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Niste odabrali proizvod!");
                return;
            }

            Domain.Product p = (Domain.Product)dgvAddProducts.SelectedRows[0].DataBoundItem;
            products.Remove(p);
        }
    }
}
