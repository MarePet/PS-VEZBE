﻿using ApplicationLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs.UserControls.Product
{
    public partial class UCAllProducts : UserControl
    {
        public UCAllProducts()
        {
            InitializeComponent();
            Init();
        }

        private void Init()
        {
            try
            {
                dgvProducts.DataSource = new BindingList<Domain.Product>(Controller.Instance.GetAllProducts());
                cbManufacturer.DataSource = Controller.Instance.GetAllManufacturers();
                cbMeasurementUnit.DataSource = Controller.Instance.GetAllMeasurementUnits();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private Domain.Product selectedProduct;
        private void button1_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Niste odabrali red!");
                return;
            }
            selectedProduct = (Domain.Product)dgvProducts.SelectedRows[0].DataBoundItem;
            txtId.Text = selectedProduct.ProductId.ToString();
            txtDescription.Text = selectedProduct.Description.ToString();
            txtName.Text = selectedProduct.Name.ToString();
            txtPrice.Text = selectedProduct.Price.ToString();

            cbMeasurementUnit.SelectedItem = selectedProduct.MeasurementUnit;
            cbManufacturer.SelectedItem = selectedProduct.Manufacturer; //da bi ovo radilo mora da bude implementirana equals metoda

        }

        private void button2_Click(object sender, EventArgs e)
        {
            selectedProduct.Name = txtName.Text;
            dgvProducts.Refresh();
        }
    }
}
