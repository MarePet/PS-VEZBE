﻿using ApplicationLogic;
using Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs.UserControls.Product
{
    public partial class UCProduct : UserControl
    {
        public UCProduct()
        {
            InitializeComponent();
            cbManufacturer.DataSource = Controller.Instance.GetAllManufacturers();
            cbMeasurementUnit.DataSource = Enum.GetValues(typeof(MeasurementUnit));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //za domaci uraditi validaciju

            Domain.Product product = new Domain.Product();
            product.Name = txtName.Text;
            product.ProductId = int.Parse(txtId.Text);
            product.Description = txtDescription.Text;
            product.Price = double.Parse(txtPrice.Text);

            product.MeasurementUnit = (MeasurementUnit)cbMeasurementUnit.SelectedItem;
            product.Manufacturer = (Manufacturer)cbManufacturer.SelectedItem;

            Controller.Instance.AddProduct(product);

            MessageBox.Show("Uspesno sacuvan proizvod!");
            //Controller.Instance.

        }
    }
}
