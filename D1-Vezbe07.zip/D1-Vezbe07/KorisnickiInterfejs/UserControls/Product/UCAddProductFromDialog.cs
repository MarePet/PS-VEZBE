﻿using ApplicationLogic;
using KorisnickiInterfejs.Dialogs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs.UserControls.Product
{
    public partial class UCAddProductFromDialog : UserControl
    {
        private BindingList<Domain.Product> products = new BindingList<Domain.Product>();
        public UCAddProductFromDialog()
        {
            InitializeComponent();
            dgvProducts.DataSource = products;
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            AddProductDialog dialog = new AddProductDialog();
            if(dialog.ShowDialog() == DialogResult.OK)
            {
                products.Add(dialog.Product);
            }
        }
    }
}
