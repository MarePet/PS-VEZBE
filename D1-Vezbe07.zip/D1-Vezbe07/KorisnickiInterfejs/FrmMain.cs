﻿using KorisnickiInterfejs.UserControls.Product;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void addProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            UCProduct product = new UCProduct();
            product.Dock = DockStyle.Fill;
            pnlMain.Controls.Add(product);
        }

        private void allProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            UCAllProducts uCAllProducts = new UCAllProducts()
            {
                Dock = DockStyle.Fill
            };
            pnlMain.Controls.Add(uCAllProducts);

        }

        private void addProductsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            UCAddProducts uCAllProducts = new UCAddProducts()
            {
                Dock = DockStyle.Fill
            };
            pnlMain.Controls.Add(uCAllProducts);
        }

        private void addProductsFromDialogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            UCAddProductFromDialog uCAllProducts = new UCAddProductFromDialog()
            {
                Dock = DockStyle.Fill
            };
            pnlMain.Controls.Add(uCAllProducts);
        }
    }
}
