﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class Manufacturer
    {
        public int ManufacturerId { get; set; }
        public string Name { get; set; }

        public Manufacturer Self { get { return this; } }
       
        public override string ToString()
        {
            return $"{ManufacturerId} {Name}";
        }

        public override bool Equals(object obj)
        {
           if(obj is Manufacturer m)
            {
                return m.ManufacturerId == ManufacturerId;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return ManufacturerId.GetHashCode();
        }
    }
}
