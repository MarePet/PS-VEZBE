﻿using DatabaseBroker;
using Domain;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=D1-ProSoft;Integrated Security=True;");
            #region insert manufacturer
            //connection.Open();
            //Manufacturer manufacturer = new Manufacturer
            //{
            //    ManufacturerId = 6,
            //    Name = "Manufacturer 6"
            //};
            //SqlCommand command = new SqlCommand();
            //command.Connection = connection;
            //command.CommandText = $"insert into manufacturer(Id, Name) values ({manufacturer.ManufacturerId}, '{manufacturer.Name}')";
            ////insert into manufacturer values (5, 'Manufacturer 5');
            //int brojRedova = command.ExecuteNonQuery();
            //connection.Close();
            #endregion
            #region get all manufacturers
            //connection.Open();
            //SqlCommand command = new SqlCommand("", connection);
            //command.CommandText = "select * from manufacturer";

            //SqlDataReader reader = command.ExecuteReader();
            //List<Manufacturer> manufacturers = new List<Manufacturer>();
            //while(reader.Read())
            //{
            //    Manufacturer m = new Manufacturer();
            //    m.ManufacturerId = (int)reader["Id"];
            //    m.Name = (string)reader["Name"];
            //    manufacturers.Add(m);
            //}

            //foreach(Manufacturer m in manufacturers)
            //{
            //    Console.WriteLine(m);
            //}

            //connection.Close();
            //Console.ReadKey();
            #endregion

            Broker broker = new Broker();
            //broker.OpenConnection();
            //Manufacturer manufacturer = new Manufacturer
            //{
            //    ManufacturerId = 6,
            //    Name = "Manufacturer 6"
            //};
            //broker.AddManufacturer(manufacturer);
            //broker.CloseConnection();

            //broker.OpenConnection();
            //List<Manufacturer> manufacturers = broker.GetManufacturers();
            //broker.CloseConnection();

            //broker.OpenConnection();
            //Product p = new Product
            //{
            //    Name = "Product 6",
            //    Description = "Des",
            //    Price = 123,
            //    MeasurementUnit = MeasurementUnit.L,
            //    Manufacturer = new Manufacturer
            //    {
            //        ManufacturerId = 1,
            //    }
            //};

            //p.ProductId = broker.GetNewProductId();
            //broker.AddProduct(p);

            //broker.CloseConnection();

            // vrati sve proizvode!
            // vrati sve proizvode sa proizvodjacem!

            User user = new User { FirstName = "Pera", LastName = "Peric", Username = "pera", Password = "pera" };


            try
            {
                broker.OpenConnection();
                int idUser = broker.AddUser(user);
                //int idUser = broker.GetLastUserId();
                Console.WriteLine(idUser);
            }
            finally
            {
                broker.CloseConnection();
            }
            Console.ReadKey();

        }
    }
}
