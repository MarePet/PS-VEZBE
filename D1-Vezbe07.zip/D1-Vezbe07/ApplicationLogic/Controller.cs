﻿using DatabaseBroker;
using Domain;
using Microsoft.Win32;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic
{
    public class Controller
    {
        private static Controller instance;
        private ProductRepository productRepository = new ProductRepository();
        private UserRepository userRepository = new UserRepository();
        private ManufacturerRepository manufacturerRepository = new ManufacturerRepository();
        private Broker broker = new Broker();

        private Controller()
        {
        }

        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }

        public List<Product> GetAllProducts()
        {
            //ovo ide u repository
            return productRepository.GetProducts();
        }

        public User Login(User user)
        {

            List<User> users = userRepository.GetUsers();

            foreach (User u in users)
            {
                if (u.Username == user.Username && u.Password == user.Password)
                {
                    return u;
                }
            }
            return null;
        }

        public Array GetAllMeasurementUnits()
        {
            return Enum.GetValues(typeof(MeasurementUnit));
        }

        public List<Manufacturer> GetAllManufacturers()
        {
            return manufacturerRepository.GetManufacturers();
        }

        public void AddProduct(Product product)
        {
            productRepository.AddProduct(product);
        }

        public void AddAllProducts(List<Product> products)
        {
            //repository
            productRepository.AddAllProducts(products);
            



        }

        //public static Controller GetInstance()
        //{
        //    if (instance == null)
        //    {
        //        instance = new Controller();
        //    }
        //    return instance;
        //}

        //public void Test()
        //{
        //    //Console.WriteLine("Test");
        //}





    }
}
